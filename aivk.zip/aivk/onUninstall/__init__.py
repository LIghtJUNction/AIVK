"""移除模块

从系统中移除 AIVK 模块，包括清理配置和依赖关系。
"""

from .__main__ import uninstall

__all__ = [
    "uninstall",
]
