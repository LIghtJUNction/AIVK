"""安装模块

安装 AIVK 模块。支持从不同源安装模块，如 PyPI、Git 等。
"""

from .__main__ import install

__all__ = [
    "install",
]
