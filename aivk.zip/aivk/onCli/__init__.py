"""命令行工具

提供 AIVK 的命令行接口和工具集。
"""

from .__main__ import cli

__all__ = [
    "cli",
]