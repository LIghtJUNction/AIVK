"""更新模块

更新已安装的 AIVK 模块到最新版本。支持版本回滚和更新检查。
"""

from .__main__ import update

__all__ = [
    "update",
]
