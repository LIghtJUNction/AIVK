"""列出模块

显示和管理 AIVK 模块信息。支持按安装状态、启用状态和类型进行过滤。
"""

from .__main__ import list
__all__ = [
    "list",
]
