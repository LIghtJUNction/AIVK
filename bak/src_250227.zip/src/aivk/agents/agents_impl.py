import os
import importlib
from typing import Dict, Any, Optional, List
from . import Base
from ..llms.llms_impl import Llms
from ..tools.tools_impl import Tools

class AgentBase:
    """Agent基类，定义所有agent共同的属性和方法"""
    def __init__(self, llm: Llms, tools: Optional[Tools] = None):
        self.llm = llm
        self.tools = tools
        self.memory: List[Dict[str, str]] = []  # 存储对话历史
        
    def add_memory(self, role: str, content: str) -> None:
        """添加对话记录"""
        self.memory.append({"role": role, "content": content})
        
    def clear_memory(self) -> None:
        """清空对话历史"""
        self.memory.clear()
        
    def run(self, prompt: str) -> str:
        """运行agent（子类必须实现）"""
        raise NotImplementedError

class Agents(Base):
    """Agents管理类"""
    def __init__(self):
        super().__init__()
        self.llm = Llms()
        self.tools = Tools()
        self._agents_cache: Dict[str, AgentBase] = {}
        self._load_agents()
    
    def _load_agents(self) -> None:
        """加载所有agent_开头的模块"""
        current_dir = os.path.dirname(__file__)
        for file in os.listdir(current_dir):
            if file.startswith('agent_') and file.endswith('.py'):
                module_name = file[:-3]
                try:
                    module = importlib.import_module(f'.{module_name}', package='aivk.agents')
                    if hasattr(module, 'Agent'):
                        self._agents_cache[module_name] = module.Agent(self.llm, self.tools)
                except Exception as e:
                    print(f"加载agent {module_name} 失败: {str(e)}")
    
    def get_agent(self, name: str) -> AgentBase:
        """获取指定的agent实例"""
        if not name.startswith('agent_'):
            name = f'agent_{name}'
        
        if name not in self._agents_cache:
            raise ValueError(f"Agent {name} 不存在")
        return self._agents_cache[name]
    
    def run(self, agent_name: str, prompt: str) -> str:
        """运行指定的agent"""
        agent = self.get_agent(agent_name)
        return agent.run(prompt)