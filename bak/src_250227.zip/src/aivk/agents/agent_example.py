from typing import List, Dict
from .agents_impl import AgentBase

class Agent(AgentBase):
    """示例Agent实现"""
    def __init__(self, llm, tools=None):
        super().__init__(llm, tools)
        # 定义agent的系统提示词
        self.system_prompt = """你是一个助手，可以帮助用户完成各种任务。
如果需要使用工具，请使用以下格式：
Action: 工具名称
Action Input: {
    "参数名": "参数值"
}
Observation: 工具返回的结果
Thought: 思考下一步行动
Answer: 最终答案"""

        self.model_id = "online_7bE6"
    
    def run(self, prompt: str) -> str:
        """运行agent"""
        # 添加用户输入到记忆
        self.add_memory("user", prompt)
        
        # 构造完整的提示词
        messages = [
            {"role": "system", "content": self.system_prompt},
            *self.memory
        ]
        
        # 获取AI响应
        response = self.llm.chat(messages = messages,model_id=self.model_id,stream=True)
        
        # 检查是否需要调用工具
        if "Action:" in response:
            # 解析工具调用
            try:
                action_lines = response.split('\n')
                tool_name = action_lines[0].split('Action:')[1].strip()
                tool_input = eval(action_lines[1].split('Action Input:')[1].strip())
                
                # 执行工具
                result = self.tools.execute(tool_name, **tool_input)
                
                # 添加工具执行结果到对话
                self.add_memory("assistant", response)
                self.add_memory("system", f"Observation: {result}")
                
                # 继续对话
                return self.run(f"根据工具执行结果 {result} 继续回答")
            except Exception as e:
                return f"工具执行失败: {str(e)}"
        
        # 添加回复到记忆
        self.add_memory("assistant", response)
        return response