import os
import importlib
from typing import List, Dict, Any, Optional
from . import Base

class Tools(Base):
    """工具管理类，负责收集和执行工具"""
    
    def __init__(self):
        super().__init__()
        self._tools_cache: Dict[str, Dict] = {}  # 缓存工具描述
        self._load_tools()

    
    def _load_tools(self) -> None:
        """加载所有tool_开头的工具模块中的工具描述"""
        current_dir = os.path.dirname(__file__)
        for file in os.listdir(current_dir):
            if file.startswith('tool_') and file.endswith('.py'):
                module_name = file[:-3]  # 移除.py后缀
                try:
                    # 动态导入模块
                    module = importlib.import_module(f'.{module_name}', package='aivk.tools')
                    
                    # 获取模块中的tool描述
                    if hasattr(module, 'tool'):
                        self._tools_cache[module_name] = module.tool
                        tool_meta = {
                            f"{module.tool['name']}": module.tool,
                        }
                        self.meta.Metadata.tools(tool_meta)
                except Exception as e:
                    print(f"加载工具 {module_name} 失败: {str(e)}")

    def get_tools(self, include: Optional[List[str]] = None,
                  exclude: Optional[List[str]] = None) -> List[Dict]:
        """获取工具描述列表"""
        result = []
        for name, desc in self._tools_cache.items():
            if include and name not in include:
                continue
            if exclude and name in exclude:
                continue
            result.append(desc)
            
        return result

    def execute(self, tool_name: str, **kwargs) -> Any:
        """执行指定的工具"""
        if not tool_name.startswith('tool_'):
            tool_name = f'tool_{tool_name}'
            
        if tool_name not in self._tools_cache:
            raise ValueError(f"工具 {tool_name} 不存在")
            
        try:
            # 动态导入并执行main函数
            module = importlib.import_module(f'.{tool_name}', package='aivk.tools')
            if hasattr(module, 'main'):
                return module.main(**kwargs)
            else:
                raise ValueError(f"工具 {tool_name} 没有main入口函数")
        except Exception as e:
            raise ValueError(f"执行工具 {tool_name} 失败: {str(e)}")