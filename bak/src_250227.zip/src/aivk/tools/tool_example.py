# 工具描述
from datetime import datetime


tool = {
    "name": "example",
    "description": "这是一个示例工具",
    "parameters": {
        "type": "object",
        "properties": {
            "param1": {
                "type": "string",
                "description": "参数1的描述"
            }
        },
        "required": ["param1"]
    }
}

def main(**kwargs):
    """工具入口函数"""
    param1 = kwargs.get('param1')
    print(f"示例工具执行: {param1}-------------------当前时间: {datetime.now()}")
    # 执行具体功能
    return f"示例工具执行结果: {param1}"