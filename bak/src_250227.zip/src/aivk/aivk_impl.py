from .base.base_impl import Base
class Aivk(Base):
    def __init__(self):
        super().__init__()
