from . import Base
class Kernel(Base):
    def __init__(self):
        super().__init__()