from . import Base
class Router(Base):
    def __init__(self):
        super().__init__()